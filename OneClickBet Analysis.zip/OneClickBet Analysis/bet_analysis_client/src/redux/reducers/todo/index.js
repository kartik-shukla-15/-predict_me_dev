import { combineReducers } from "redux"
import todo from "./todo"

export default combineReducers({
  todo
})
